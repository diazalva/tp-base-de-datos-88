CREATE DATABASE IF NOT EXISTS tienda_tp8
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;
USE tienda_tp8;

DROP TABLE IF EXISTS detalle_ventas;
DROP TABLE IF EXISTS ventas;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS metodos_pago;
DROP TABLE IF EXISTS clientes;

CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE productos (
    id_producto  INT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(100)   NOT NULL,
    precio       DECIMAL(10,2)  NOT NULL CHECK (precio >= 0),
    stock        INT            NOT NULL DEFAULT 0 CHECK (stock >= 0),
    activo       TINYINT(1)     NOT NULL DEFAULT 1,
    id_categoria INT            NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
) ENGINE=InnoDB;

CREATE TABLE clientes (
    id_cliente     INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(50)  NOT NULL,
    apellido       VARCHAR(50)  NOT NULL,
    email          VARCHAR(100) NOT NULL UNIQUE,
    ciudad         VARCHAR(50)  NOT NULL,
    fecha_registro DATE         NOT NULL
) ENGINE=InnoDB;

CREATE TABLE metodos_pago (
    id_metodo_pago INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE ventas (
    id_venta       INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente     INT  NOT NULL,
    id_metodo_pago INT  NOT NULL,
    fecha          DATE NOT NULL,
    estado_pago    ENUM('pendiente','pagado','rechazado') NOT NULL DEFAULT 'pendiente',
    FOREIGN KEY (id_cliente)     REFERENCES clientes(id_cliente),
    FOREIGN KEY (id_metodo_pago) REFERENCES metodos_pago(id_metodo_pago)
) ENGINE=InnoDB;

CREATE TABLE detalle_ventas (
    id_detalle      INT AUTO_INCREMENT PRIMARY KEY,
    id_venta        INT           NOT NULL,
    id_producto     INT           NOT NULL,
    cantidad        INT           NOT NULL CHECK (cantidad > 0),
    precio_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_venta)    REFERENCES ventas(id_venta),
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
) ENGINE=InnoDB;

INSERT INTO categorias (nombre) VALUES
    ('Electrónica'), ('Indumentaria'), ('Hogar'), ('Accesorios'), ('Libros');

INSERT INTO productos (nombre, precio, stock, activo, id_categoria) VALUES
    ('Auriculares Bluetooth',  4500.00, 25, 1, 1),
    ('Cargador USB-C',         3200.00, 40, 1, 1),
    ('Teclado Mecánico',      18500.00, 10, 1, 1),
    ('Zapatillas Urbanas',    32000.00, 15, 1, 2),
    ('Remera de Algodón',      6500.00, 50, 1, 2),
    ('Campera Impermeable',   28000.00,  0, 1, 2),
    ('Lámpara de Escritorio',  7800.00, 20, 1, 3),
    ('Set de Sábanas',        14500.00, 12, 1, 3),
    ('Mochila Urbana',         9800.00, 30, 1, 4),
    ('Billetera de Cuero',     4200.00, 35, 1, 4),
    ('Gorra Deportiva',        2500.00, 60, 0, 4),
    ('Mouse Inalámbrico',      3900.00,  5, 1, 1);

INSERT INTO clientes (nombre, apellido, email, ciudad, fecha_registro) VALUES
    ('Lucía',    'Fernández', 'lucia.fernandez@ejemplo.com', 'Córdoba',  DATE_SUB(CURDATE(), INTERVAL 120 DAY)),
    ('Martín',   'Gómez',     'martin.gomez@ejemplo.com',    'Rosario',  DATE_SUB(CURDATE(), INTERVAL 100 DAY)),
    ('Sofía',    'Ramírez',   'sofia.ramirez@ejemplo.com',   'Córdoba',  DATE_SUB(CURDATE(), INTERVAL 80 DAY)),
    ('Tomás',    'Herrera',   'tomas.herrera@ejemplo.com',   'Mendoza',  DATE_SUB(CURDATE(), INTERVAL 60 DAY)),
    ('Valentina','Díaz',      'valentina.diaz@ejemplo.com',  'Salta',    DATE_SUB(CURDATE(), INTERVAL 30 DAY)),
    ('Joaquín',  'Castro',    'joaquin.castro@ejemplo.com',  'Córdoba',  DATE_SUB(CURDATE(), INTERVAL 10 DAY));

INSERT INTO metodos_pago (nombre) VALUES
    ('Mercado Pago'), ('Transferencia bancaria'), ('Tarjeta de débito'), ('Efectivo');

INSERT INTO ventas (id_cliente, id_metodo_pago, fecha, estado_pago) VALUES
    (1, 1, DATE_SUB(CURDATE(), INTERVAL 45 DAY), 'pagado'),
    (2, 2, DATE_SUB(CURDATE(), INTERVAL 40 DAY), 'pagado'),
    (3, 1, DATE_SUB(CURDATE(), INTERVAL 25 DAY), 'pagado'),
    (1, 3, DATE_SUB(CURDATE(), INTERVAL 20 DAY), 'pagado'),
    (4, 1, DATE_SUB(CURDATE(), INTERVAL 18 DAY), 'pagado'),
    (2, 1, DATE_SUB(CURDATE(), INTERVAL 15 DAY), 'pagado'),
    (5, 4, DATE_SUB(CURDATE(), INTERVAL 12 DAY), 'pendiente'),
    (3, 2, DATE_SUB(CURDATE(), INTERVAL 10 DAY), 'pagado'),
    (1, 1, DATE_SUB(CURDATE(), INTERVAL 7 DAY),  'pagado'),
    (4, 3, DATE_SUB(CURDATE(), INTERVAL 5 DAY),  'pagado'),
    (5, 1, DATE_SUB(CURDATE(), INTERVAL 3 DAY),  'rechazado'),
    (2, 1, DATE_SUB(CURDATE(), INTERVAL 1 DAY),  'pagado');

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario) VALUES
    (1,  1, 1,  4500.00), (1,  5, 2,  6500.00),
    (2,  3, 1, 18500.00),
    (3,  4, 1, 32000.00), (3, 10, 1,  4200.00),
    (4,  2, 2,  3200.00), (4,  9, 1,  9800.00),
    (5,  7, 1,  7800.00), (5,  8, 1, 14500.00),
    (6,  5, 3,  6500.00), (6, 10, 1,  4200.00),
    (7,  6, 1, 28000.00),
    (8,  1, 2,  4500.00), (8, 12, 1,  3900.00),
    (9,  3, 1, 18500.00), (9,  2, 1,  3200.00),
    (10, 9, 2,  9800.00), (10, 5, 1,  6500.00),
    (11, 4, 1, 32000.00),
    (12, 1, 1,  4500.00), (12, 7, 2,  7800.00), (12, 10, 1, 4200.00);

SELECT id_producto, nombre, precio, stock
FROM productos
WHERE activo = 1
  AND precio < 5000
ORDER BY precio ASC;

SELECT id_producto, nombre, stock
FROM productos
WHERE activo = 1
  AND stock <= 10
ORDER BY stock ASC, nombre ASC;

SELECT id_cliente, apellido, nombre, email
FROM clientes
WHERE ciudad = 'Córdoba'
ORDER BY apellido ASC, nombre ASC;

SELECT v.id_venta,
       v.fecha,
       CONCAT(c.nombre, ' ', c.apellido) AS cliente,
       mp.nombre                         AS metodo_pago
FROM ventas v
INNER JOIN clientes     c  ON v.id_cliente     = c.id_cliente
INNER JOIN metodos_pago mp ON v.id_metodo_pago = mp.id_metodo_pago
WHERE v.estado_pago = 'pagado'
ORDER BY v.fecha DESC;

SELECT p.nombre    AS producto,
       cat.nombre  AS categoria,
       p.precio
FROM productos p
INNER JOIN categorias cat ON p.id_categoria = cat.id_categoria
WHERE p.activo = 1
  AND p.precio BETWEEN 5000 AND 20000
ORDER BY cat.nombre ASC, p.precio ASC;

SELECT cat.nombre                AS categoria,
       COUNT(p.id_producto)      AS cantidad_productos
FROM categorias cat
LEFT JOIN productos p ON p.id_categoria = cat.id_categoria
GROUP BY cat.id_categoria, cat.nombre
ORDER BY cantidad_productos DESC, categoria ASC;

SELECT mp.nombre            AS metodo_pago,
       COUNT(v.id_venta)    AS cantidad_ventas
FROM metodos_pago mp
INNER JOIN ventas v ON v.id_metodo_pago = mp.id_metodo_pago
WHERE v.estado_pago = 'pagado'
GROUP BY mp.id_metodo_pago, mp.nombre
ORDER BY cantidad_ventas DESC;

SELECT cat.nombre                 AS categoria,
       ROUND(AVG(p.precio), 2)    AS precio_promedio
FROM productos p
INNER JOIN categorias cat ON p.id_categoria = cat.id_categoria
WHERE p.activo = 1
GROUP BY cat.id_categoria, cat.nombre
ORDER BY precio_promedio DESC;

SELECT p.nombre                              AS producto,
       SUM(d.cantidad)                       AS unidades_vendidas,
       SUM(d.cantidad * d.precio_unitario)   AS total_recaudado
FROM detalle_ventas d
INNER JOIN productos p ON d.id_producto = p.id_producto
INNER JOIN ventas    v ON d.id_venta    = v.id_venta
WHERE v.estado_pago = 'pagado'
GROUP BY p.id_producto, p.nombre
ORDER BY unidades_vendidas DESC, total_recaudado DESC
LIMIT 5;

SELECT c.id_cliente,
       CONCAT(c.nombre, ' ', c.apellido)       AS cliente,
       COUNT(DISTINCT v.id_venta)              AS cantidad_compras,
       SUM(d.cantidad * d.precio_unitario)     AS total_gastado
FROM clientes c
INNER JOIN ventas         v ON v.id_cliente = c.id_cliente
INNER JOIN detalle_ventas d ON d.id_venta   = v.id_venta
WHERE v.estado_pago = 'pagado'
  AND v.fecha >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
GROUP BY c.id_cliente, c.nombre, c.apellido
ORDER BY total_gastado DESC
LIMIT 5;
