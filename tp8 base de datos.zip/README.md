# TP N° 8 – Especificación de Requisitos y Consultas SQL

**Base de Datos 1 – 2026 – IPET 247**
**Alumno:** Álvaro Díaz  **Curso:** 6° E
**Proyecto personal:** Sistema de base de datos para una tienda de ventas

---

## 1. Descripción del sistema

### 1.1 Propósito
Este documento especifica los requisitos orientados a los datos de una **base de datos para una tienda de ventas**. El sistema guarda productos, clientes, ventas y pagos, para que quien administra la tienda pueda saber qué se vendió, a quién, cuándo, cómo se pagó y cuánto dinero se generó.

### 1.2 Alcance
**Incluye:**
- Registro de categorías, productos (con precio y stock) y clientes.
- Registro de ventas con su detalle (qué productos y qué cantidades), el método de pago y el estado del pago.
- Consultas para reportes de gestión (inventario, ventas, clientes y recaudación).

**Queda fuera del alcance (versión inicial):**
- Interfaz web o aplicación para el usuario final.
- Integración real con pasarelas de pago.
- Facturación electrónica.

### 1.3 Usuarios
| Rol | Descripción |
|-----|-------------|
| Administrador/a de la tienda | Carga productos y clientes, consulta reportes y toma decisiones (reposición de stock, productos más vendidos, mejores clientes). |
| Vendedor/a | Registra ventas y confirma el estado de los pagos. |

### 1.4 Modelo de datos (resumen)

| Tabla | Descripción | Claves |
|-------|-------------|--------|
| `categorias` | Categorías de productos | PK `id_categoria` |
| `productos` | Productos con precio, stock y si están activos | PK `id_producto`, FK `id_categoria` |
| `clientes` | Clientes de la tienda | PK `id_cliente` |
| `metodos_pago` | Formas de pago disponibles | PK `id_metodo_pago` |
| `ventas` | Cabecera de cada venta (fecha, estado de pago) | PK `id_venta`, FK `id_cliente`, FK `id_metodo_pago` |
| `detalle_ventas` | Productos y cantidades de cada venta | PK `id_detalle`, FK `id_venta`, FK `id_producto` |

Relaciones: una categoría tiene muchos productos; un cliente realiza muchas ventas; una venta tiene un método de pago y muchos ítems en `detalle_ventas`; un producto puede aparecer en muchos detalles.

> Los datos de ejemplo de `consultas.sql` son **ficticios**; no corresponden a personas reales.

---

## 2. Requisitos funcionales (orientados a los datos)

Prioridad según el método MoSCoW: **M** = Must have, **S** = Should have.

### RF-01: Registro de clientes — *(M)*
**Formato (User Story):** "Como vendedor/a, quiero registrar a un cliente con nombre, apellido, email y ciudad, para poder asociarle sus compras."
- **Regla de negocio:** el email de cada cliente debe ser único.
- **Criterios de aceptación:** el cliente queda guardado con su fecha de registro; si el email ya existe, el sistema rechaza el alta.

### RF-02: Gestión de productos e inventario — *(M)*
**Formato (Caso de uso resumido):** "El sistema permite al administrador/a registrar productos con nombre, precio, stock y categoría, y marcarlos como activos o inactivos."
- **Regla de negocio:** el precio y el stock no pueden ser negativos; un producto inactivo no puede venderse.
- **Criterios de aceptación:** cada producto pertenece a una categoría existente; los productos inactivos no aparecen en los listados de venta.

### RF-03: Registro de ventas con su detalle — *(M)*
**Formato (EARS):** "Cuando se realice una venta, el sistema deberá registrar el cliente, la fecha, el método de pago y los productos con su cantidad y el precio unitario vigente."
- **Regla de negocio:** no se puede vender un producto sin stock; el precio queda guardado en `detalle_ventas.precio_unitario`, de modo que cambios futuros de precio no alteren ventas anteriores.
- **Criterios de aceptación:** cada venta tiene un cliente y un método de pago válidos y al menos un producto en su detalle.

### RF-04: Registro y verificación del estado del pago — *(M)*
**Formato (EARS):** "Cuando se registre una venta, el sistema deberá guardar su estado de pago (`pendiente`, `pagado` o `rechazado`), y cuando el pago sea confirmado deberá cambiar el estado a `pagado`."
- **Regla de negocio:** toda venta nace como `pendiente`; solo las ventas `pagado` cuentan para los reportes de recaudación.
- **Criterios de aceptación:** el estado solo admite los tres valores definidos; los reportes de ingresos excluyen ventas pendientes y rechazadas.

### RF-05: Reportes de gestión — *(S)*
**Formato (Caso de uso resumido):** "El sistema permite al administrador/a consultar el stock bajo, los productos más vendidos, la recaudación por producto y los clientes que más gastaron en un período."
- **Regla de negocio:** los totales monetarios se calculan como `cantidad × precio_unitario` solo de ventas con pago confirmado.
- **Criterios de aceptación:** las 10 consultas de la sección 3 devuelven los resultados esperados en phpMyAdmin.

---

## 3. Listado de consultas principales (lenguaje natural)

| N° | Tipo | Consulta |
|----|------|----------|
| 1 | Simple (`WHERE`, `ORDER BY`) | Listar todos los productos activos del inventario con precio menor a $5000, ordenados de menor a mayor precio. |
| 2 | Simple (`WHERE`, `ORDER BY`) | ¿Qué productos activos tienen stock bajo (10 unidades o menos) y necesitan reposición? Mostrar primero los de menor stock. |
| 3 | Simple (`WHERE`, `ORDER BY`) | Listar los clientes que viven en Córdoba, ordenados alfabéticamente por apellido y nombre. |
| 4 | `JOIN` (3 tablas) | Listar las ventas con pago confirmado, mostrando fecha, nombre del cliente y método de pago, de la más reciente a la más antigua. |
| 5 | `JOIN` + `BETWEEN` | Mostrar los productos activos con precio entre $5000 y $20000, indicando su categoría, ordenados por categoría y luego por precio. |
| 6 | `COUNT` + `GROUP BY` + `LEFT JOIN` | ¿Cuántos productos tiene cada categoría? Incluir también las categorías sin productos. |
| 7 | `COUNT` + `GROUP BY` + `JOIN` | ¿Cuántas ventas con pago confirmado se realizaron con cada método de pago? Ordenar de más a menos utilizado. |
| 8 | `AVG` + `GROUP BY` + `JOIN` | ¿Cuál es el precio promedio de los productos activos de cada categoría? Ordenar de mayor a menor. |
| 9 | `SUM` + `GROUP BY` + `JOIN` + `LIMIT` | ¿Cuáles son los 5 productos más vendidos (en unidades), considerando solo ventas pagadas, y cuánto dinero generó cada uno? |
| 10 | Avanzada (`JOIN`, `SUM`, `COUNT`, `GROUP BY`, fecha, `LIMIT`) | Obtener el listado de los 5 clientes que más dinero gastaron durante el último mes (solo ventas pagadas), con la cantidad de compras y el total acumulado. |

Las sentencias SQL de cada consulta están en [`consultas.sql`](consultas.sql), comentadas con su número y su pregunta.

---

## 4. Cómo ejecutar el proyecto (phpMyAdmin – XAMPP)

1. Iniciar **Apache** y **MySQL** desde el panel de XAMPP.
2. Entrar a `http://localhost/phpmyadmin`.
3. Ir a la pestaña **SQL**, pegar el contenido de `consultas.sql` y presionar **Continuar** (o usar **Importar**).
4. Se crea la base `tienda_tp8` con datos de ejemplo. Luego se pueden ejecutar las consultas de la Parte B de a una.

---

## 5. Ficha de Declaración de IA

| Herramienta | Propósito | Prompt utilizado | Ajuste / Edición | Aprendizaje |
|-------------|-----------|------------------|------------------|-------------|
|  |  |  |  |  |

**Declaración de uso de IA:** el código SQL de `consultas.sql` (esquema, datos de ejemplo y las 10 consultas) fue elaborado con la ayuda de Claude, un asistente de IA de Anthropic.
